

var living     = "<img src='img/living.png' height=100>";
var nonliving  = "<img src='img/nonliving.png'height=100 style='padding-left: 20px;'>";
var smaller    = "<img src='img/smaller.png' height=100 style='padding-right: 20px;'>";
var larger     = "<img src='img/larger.png' height=100 style='padding-right: 20px;'>";

//-------------------- Response prompts

var prompt_living  = "<div style='float:right; text-align: right;' >" + living  +  "</div>";
var prompt_nonliving  = "<div style='float:left;  text-align: left;'  >" + nonliving + "</div>";
var prompt_smaller = "<div style='float:left;  text-align: left;'  >" + smaller + "</div>";
var prompt_larger   = "<div style='float:right; text-align: right;' >" + larger + "</div>";



// stimuli retrieved from https://osf.io/h3e7w/
