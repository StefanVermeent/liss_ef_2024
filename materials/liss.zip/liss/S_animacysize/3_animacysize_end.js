//------------------------- End of the task and save data

var animacysize_end = {
  type: jsPsychHtmlButtonResponse,
  stimulus: "Goed gedaan!<br><br>" +
  "U bent nu klaar met het Dieren en Objecten spel.<br><br>" +
  "Klik op 'verder' om door te gaan.<br><br>",
  choices: ['verder'],
  data: {variable: "end", task: "animacysize"},
};
