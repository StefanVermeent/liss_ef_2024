//------------------------- Functions

  // Fixation cross
  var posner_fixation = {
  type: jsPsychHtmlKeyboardResponse,
  stimulus: '<div style="font-size:60px;">+</div>',
  choices: 'NO_KEYS',
  trial_duration: 1000,
  data: {
    variable: 'fixation',
    stimulus: ""
  }
}


