//------------------------- End of the task and save data

var colorshape_end = {
  type: jsPsychHtmlButtonResponse,
  stimulus: "Goed gedaan!<br><br>" +
  "U bent nu klaar met het Kleuren en Vormen spel.<br><br>" +
  "Klik op 'verder' om door te gaan.<br><br>",
  choices: ['verder'],
  data: {variable: "colorshape_finish", task: "colorshape"},
};
